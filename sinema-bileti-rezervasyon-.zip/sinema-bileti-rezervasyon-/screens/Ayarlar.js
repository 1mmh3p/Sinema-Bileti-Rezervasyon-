import React from 'react';
import { View, Text, StyleSheet, Switch, TouchableOpacity, Alert, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { supabase } from '../lib/supabase';

const Ayarlar = ({ navigation }) => {
  const [settings, setSettings] = React.useState({
    notifications: true,
    darkMode: false,
    biometricLogin: false
  });

  const handleLogout = async () => {
    Alert.alert(
      'Çıkış Yap',
      'Hesabınızdan çıkış yapmak istediğinize emin misiniz?',
      [
        {
          text: 'İptal',
          style: 'cancel'
        },
        { 
          text: 'Çıkış Yap', 
          onPress: async () => {
            try {
              const { error } = await supabase.auth.signOut();
              if (error) throw error;
              navigation.replace('GirisYap');
            } catch (error) {
              Alert.alert('Hata', error.message);
            }
          } 
        }
      ]
    );
  };

  const toggleSwitch = (setting) => {
    setSettings(prev => ({
      ...prev,
      [setting]: !prev[setting]
    }));
  };

  const settingsItems = [
    {
      icon: 'notifications',
      title: 'Bildirimler',
      description: 'Uygulama bildirimlerini aç/kapat',
      type: 'switch',
      value: settings.notifications,
      onPress: () => toggleSwitch('notifications')
    },
    {
      icon: 'moon',
      title: 'Karanlık Mod',
      description: 'Arayüzü karanlık moda geçir',
      type: 'switch',
      value: settings.darkMode,
      onPress: () => toggleSwitch('darkMode')
    },
    {
      icon: 'finger-print',
      title: 'Parmak İzi ile Giriş',
      description: 'Parmak izi kullanarak hızlı giriş yap',
      type: 'switch',
      value: settings.biometricLogin,
      onPress: () => toggleSwitch('biometricLogin')
    },
    {
      icon: 'language',
      title: 'Dil',
      description: 'Uygulama dilini değiştir',
      type: 'navigate',
      onPress: () => navigation.navigate('DilAyarlari')
    },
    {
      icon: 'lock-closed',
      title: 'Gizlilik',
      description: 'Gizlilik ayarlarını yönet',
      type: 'navigate',
      onPress: () => navigation.navigate('Gizlilik')
    },
    {
      icon: 'card',
      title: 'Ödeme Yöntemleri',
      description: 'Kayıtlı ödeme yöntemlerini yönet',
      type: 'navigate',
      onPress: () => navigation.navigate('OdemeYontemleri')
    },
    {
      icon: 'help-circle',
      title: 'Yardım',
      description: 'Yardım merkezi ve SSS',
      type: 'navigate',
      onPress: () => navigation.navigate('Yardim')
    },
    {
      icon: 'information-circle',
      title: 'Hakkında',
      description: 'Uygulama versiyonu ve lisans bilgileri',
      type: 'navigate',
      onPress: () => navigation.navigate('Hakkinda')
    }
  ];

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={['#4A6FA5', '#3A5A80']}
        style={styles.header}
      >
        <Text style={styles.headerTitle}>Ayarlar</Text>
      </LinearGradient>

      <ScrollView style={styles.content}>
        {settingsItems.map((item, index) => (
          <TouchableOpacity 
            key={index}
            style={styles.settingItem}
            onPress={item.onPress}
          >
            <View style={styles.settingIcon}>
              <Ionicons name={item.icon} size={24} color="#4A6FA5" />
            </View>
            
            <View style={styles.settingInfo}>
              <Text style={styles.settingTitle}>{item.title}</Text>
              <Text style={styles.settingDescription}>{item.description}</Text>
            </View>
            
            {item.type === 'switch' ? (
              <Switch
                value={item.value}
                onValueChange={item.onPress}
                trackColor={{ false: "#767577", true: "#81b0ff" }}
                thumbColor={item.value ? "#4A6FA5" : "#f4f3f4"}
              />
            ) : (
              <Ionicons name="chevron-forward" size={20} color="#ccc" />
            )}
          </TouchableOpacity>
        ))}

        <TouchableOpacity 
          style={styles.logoutButton}
          onPress={handleLogout}
        >
          <View style={[styles.settingIcon, { backgroundColor: 'rgba(244,67,54,0.1)' }]}>
            <Ionicons name="log-out" size={24} color="#F44336" />
          </View>
          
          <View style={styles.settingInfo}>
            <Text style={[styles.settingTitle, { color: '#F44336' }]}>Çıkış Yap</Text>
            <Text style={styles.settingDescription}>Hesabınızdan güvenli çıkış yapın</Text>
          </View>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    padding: 20,
    paddingTop: 50,
    paddingBottom: 30,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
  },
  content: {
    flex: 1,
    marginTop: -20,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    backgroundColor: '#fff',
    padding: 20,
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  settingIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(74,111,165,0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  settingInfo: {
    flex: 1,
  },
  settingTitle: {
    fontSize: 16,
    fontWeight: '500',
    color: '#333',
  },
  settingDescription: {
    fontSize: 14,
    color: '#999',
    marginTop: 3,
  },
  logoutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 15,
    marginTop: 20,
  },
});

export default Ayarlar;