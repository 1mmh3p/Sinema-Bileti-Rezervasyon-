import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, Image, StyleSheet, ActivityIndicator, TouchableOpacity, Linking } from 'react-native';
import MapView, { Marker } from 'react-native-maps';
import cinemasData from './cinemas.json';

const SinemaHaritam = () => {
  const [sinemalar, setSinemalar] = useState([]);
  const [yukleniyor, setYukleniyor] = useState(true);
  const [hata, setHata] = useState(null);
  const [seciliSinema, setSeciliSinema] = useState(null);

  useEffect(() => {
    // Gerçek uygulamada API'den veri çekilecek
    setTimeout(() => {
      setSinemalar(cinemasData);
      setYukleniyor(false);
    }, 1000);
  }, []);

  const haritadaAc = (enlem, boylam) => {
    const url = `https://www.google.com/maps/search/?api=1&query=${enlem},${boylam}`;
    Linking.openURL(url).catch(err => console.error('Harita açılamadı:', err));
  };

  const sinemaOgesi = ({ item }) => (
    <TouchableOpacity 
      style={stiller.sinemaOgesi} 
      onPress={() => setSeciliSinema(item)}
    >
      <Image
        source={{ uri: item.resim || 'https://via.placeholder.com/150' }}
        style={stiller.sinemaResmi}
      />
      <View style={stiller.sinemaBilgisi}>
        <Text style={stiller.sinemaAdi}>{item.ad}</Text>
        <Text style={stiller.sinemaAdresi}>{item.adres}</Text>
        <Text style={stiller.sinemaTelefon}>{item.telefon}</Text>
      </View>
    </TouchableOpacity>
  );

  if (yukleniyor) {
    return (
      <View style={stiller.merkez}>
        <ActivityIndicator size="large" color="#E50914" />
        <Text style={stiller.yukleniyorMetni}>Yükleniyor...</Text>
      </View>
    );
  }

  if (hata) {
    return (
      <View style={stiller.merkez}>
        <Text style={stiller.hataMetni}>Hata oluştu: {hata}</Text>
      </View>
    );
  }

  return (
    <View style={stiller.kapsayici}>
      <View style={stiller.baslik}>
        <Text style={stiller.baslikMetni}>Türkiye'deki Sinemalar</Text>
      </View>

      {seciliSinema ? (
        <View style={stiller.detayKapsayici}>
          <MapView
            style={stiller.harita}
            initialRegion={{
              latitude: seciliSinema.enlem,
              longitude: seciliSinema.boylam,
              latitudeDelta: 0.02,
              longitudeDelta: 0.02,
            }}
          >
            <Marker
              coordinate={{
                latitude: seciliSinema.enlem,
                longitude: seciliSinema.boylam,
              }}
              title={seciliSinema.ad}
            />
          </MapView>

          <View style={stiller.detayBilgisi}>
            <Text style={stiller.detayAd}>{seciliSinema.ad}</Text>
            <Text style={stiller.detayAdres}>{seciliSinema.adres}</Text>
            <Text style={stiller.detayTelefon}>{seciliSinema.telefon}</Text>
            
            <Text style={stiller.filmlerBaslik}>Vizyondaki Filmler</Text>
            {seciliSinema.filmler.map((film, index) => (
              <Text key={index} style={stiller.filmOgesi}>• {film}</Text>
            ))}

            <TouchableOpacity 
              style={stiller.haritaButonu}
              onPress={() => haritadaAc(seciliSinema.enlem, seciliSinema.boylam)}
            >
              <Text style={stiller.haritaButonMetni}>Haritada Göster</Text>
            </TouchableOpacity>

            <TouchableOpacity 
              style={stiller.geriButonu}
              onPress={() => setSeciliSinema(null)}
            >
              <Text style={stiller.geriButonMetni}>Geri Dön</Text>
            </TouchableOpacity>
          </View>
        </View>
      ) : (
        <FlatList
          data={sinemalar}
          renderItem={sinemaOgesi}
          keyExtractor={(item) => item.id.toString()}
          contentContainerStyle={stiller.listeIcerik}
        />
      )}
    </View>
  );
};

const stiller = StyleSheet.create({
  kapsayici: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  merkez: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  baslik: {
    padding: 15,
    backgroundColor: '#E50914',
  },
  baslikMetni: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'white',
    textAlign: 'center',
  },
  sinemaOgesi: {
    flexDirection: 'row',
    backgroundColor: 'white',
    margin: 10,
    borderRadius: 8,
    overflow: 'hidden',
    elevation: 3,
  },
  sinemaResmi: {
    width: 120,
    height: 150,
  },
  sinemaBilgisi: {
    flex: 1,
    padding: 10,
    justifyContent: 'center',
  },
  sinemaAdi: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 5,
    color: '#333',
  },
  sinemaAdresi: {
    fontSize: 14,
    color: '#666',
    marginBottom: 5,
  },
  sinemaTelefon: {
    fontSize: 14,
    color: '#E50914',
  },
  detayKapsayici: {
    flex: 1,
  },
  harita: {
    height: 300,
  },
  detayBilgisi: {
    padding: 20,
  },
  detayAd: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#333',
  },
  detayAdres: {
    fontSize: 16,
    color: '#666',
    marginBottom: 10,
  },
  detayTelefon: {
    fontSize: 16,
    color: '#E50914',
    marginBottom: 20,
  },
  filmlerBaslik: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#333',
  },
  filmOgesi: {
    fontSize: 16,
    marginBottom: 5,
    color: '#555',
  },
  haritaButonu: {
    backgroundColor: '#E50914',
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 20,
  },
  haritaButonMetni: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 16,
  },
  geriButonu: {
    backgroundColor: '#333',
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 10,
  },
  geriButonMetni: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 16,
  },
  yukleniyorMetni: {
    marginTop: 10,
    fontSize: 16,
    color: '#666',
  },
  hataMetni: {
    fontSize: 18,
    color: 'red',
  },
  listeIcerik: {
    paddingBottom: 20,
  },
});

export default SinemaHaritam;