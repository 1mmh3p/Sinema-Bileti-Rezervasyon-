import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image, ScrollView, TextInput } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '../lib/supabase';

const GirisYap = ({ navigation }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handlePress = () => {
    navigation.navigate('SinemaHaritam'); 
  };
  const handleLogin = async () => {
    setLoading(true);
    setError(null);
    try {
      const { error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });
      if (error) throw error;
    } catch (error) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <LinearGradient
      colors={['#2c3e50', '#4ca1af']}
      style={styles.container}
    >
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        {/* Logo veya Etkinlik resmi */}
        <Image 
          source={{ uri: 'https://png.pngtree.com/png-vector/20220525/ourmid/pngtree-two-cinema-tickets-ticket-movie-png-image_4739393.png' }} 
          style={styles.logo} 
        />

        <Text style={styles.baslik}>Etkinlik ve Sinema Giriş</Text>
        <Text style={styles.altBaslik}>Türkiye'nin en iyi etkinlik ve film platformuna hoş geldiniz</Text>

        <View style={styles.formContainer}>
          {/* E-posta giriş */}
          <View style={styles.inputContainer}>
            <Ionicons name="mail" size={20} color="#666" style={styles.inputIcon} />
            <TextInput
              style={styles.input}
              placeholder="E-posta adresiniz"
              placeholderTextColor="#999"
              onChangeText={setEmail}
              value={email}
              keyboardType="email-address"
              autoCapitalize="none"
            />
          </View>

          {/* Şifre giriş */}
          <View style={styles.inputContainer}>
            <Ionicons name="lock-closed" size={20} color="#666" style={styles.inputIcon} />
            <TextInput
              style={styles.input}
              placeholder="Şifreniz"
              placeholderTextColor="#999"
              onChangeText={setPassword}
              value={password}
              secureTextEntry
            />
          </View>

          {/* Hata mesajı */}
          {error && (
            <Text style={[styles.hataMetni, { textAlign: 'center' }]}>{error}</Text>
          )}

          {/* Giriş butonu */}
          <TouchableOpacity 
            style={styles.girisButon} 
            onPress={handleLogin}
            disabled={loading}
          >
            <Text style={styles.girisButonMetni}>
              {loading ? 'Giriş yapılıyor...' : 'Giriş Yap'}
            </Text>
          </TouchableOpacity>

          {/* Şifremi unuttum */}
          <TouchableOpacity style={styles.sifreUnuttum} onPress={() => {/* Şifre reset fonksiyonu */}}>
            <Text style={styles.sifreUnuttumMetni}>Şifrenizi mi unuttunuz?</Text>
          </TouchableOpacity>

          {/* Ayraç */}
          <View style={styles.ayracContainer}>
            <View style={styles.ayracCizgi} />
            <Text style={styles.ayracMetni}>veya</Text>
            <View style={styles.ayracCizgi} />
          </View>

          {/* Yeni hesap oluştur */}
          <TouchableOpacity 
            style={styles.kayitButon}
            onPress={() => navigation.navigate('KayitOl')}
          >
            <Text style={styles.kayitButonMetni}>Yeni Hesap Oluştur</Text>
          </TouchableOpacity>
        </View>

            <View style={styles.populerContainer}>
      <Text style={styles.populerBaslik}>Popüler Etkinlikler & Filmler</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false}>
        
        <TouchableOpacity style={styles.card} onPress={handlePress}>
          <Image 
            source={{ uri: 'https://images.unsplash.com/photo-1549924231-f129b911e442?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80' }} 
            style={styles.cardImage} 
          />
          <Text style={styles.cardText}>İstanbul Film Festivali</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.card} onPress={handlePress}>
          <Image 
            source={{ uri: 'https://images.unsplash.com/photo-1549924231-f129b911e442?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80' }} 
            style={styles.cardImage} 
          />
          <Text style={styles.cardText}>Ankara Açık Hava Sineması</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.card} onPress={handlePress}>
          <Image 
            source={{ uri: 'https://images.unsplash.com/photo-1549924231-f129b911e442?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80' }} 
            style={styles.cardImage} 
          />
          <Text style={styles.cardText}>İzmir Konserleri</Text>
        </TouchableOpacity>

      </ScrollView>
    </View>
      </ScrollView>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContainer: {
    flexGrow: 1,
    justifyContent: 'center',
    padding: 20,
  },
  logo: {
    width: 120,
    height: 120,
    alignSelf: 'center',
    marginBottom: 20,
    borderRadius: 60,
  },
  baslik: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#fff',
    textAlign: 'center',
  },
  altBaslik: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.8)',
    textAlign: 'center',
    marginBottom: 20,
  },
  formContainer: {
    backgroundColor: '#fff',
    borderRadius: 15,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 4,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 10,
    paddingHorizontal: 10,
    marginBottom: 15,
    backgroundColor: '#f0f0f0',
  },
  inputIcon: {
    marginRight: 8,
  },
  input: {
    flex: 1,
    height: 45,
    fontSize: 14,
    color: '#333',
  },
  hataMetni: {
    color: '#e74c3c',
    fontSize: 12,
    marginBottom: 10,
  },
  girisButon: {
    backgroundColor: '#2980b9',
    paddingVertical: 14,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 10,
  },
  girisButonMetni: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  sifreUnuttum: {
    alignSelf: 'flex-end',
    marginTop: 10,
  },
  sifreUnuttumMetni: {
    color: '#2980b9',
    fontSize: 14,
  },
  ayracContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 20,
  },
  ayracCizgi: {
    flex: 1,
    height: 1,
    backgroundColor: '#ccc',
  },
  ayracMetni: {
    marginHorizontal: 10,
    color: '#999',
    fontSize: 14,
  },
  kayitButon: {
    borderWidth: 1,
    borderColor: '#2980b9',
    padding: 14,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 10,
  },
  kayitButonMetni: {
    color: '#2980b9',
    fontSize: 16,
    fontWeight: 'bold',
  },
  populerContainer: {
    marginTop: 30,
  },
  populerBaslik: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 10,
    textAlign: 'center',
  },
  card: {
    width: 180,
    marginRight: 15,
    borderRadius: 10,
    overflow: 'hidden',
    backgroundColor: '#fff',
  },
  cardImage: {
    width: '100%',
    height: 100,
  },
  cardText: {
    padding: 8,
    fontSize: 14,
    textAlign: 'center',
  },
});

export default GirisYap;