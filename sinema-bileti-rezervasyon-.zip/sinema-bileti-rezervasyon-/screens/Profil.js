import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image, ScrollView, Alert, ActivityIndicator, RefreshControl } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { supabase, getUserProfile, getUserBookings } from '../lib/supabase';

const Profil = ({ navigation }) => {
  const [user, setUser] = useState(null);
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [refreshing, setRefreshing] = useState(false);

  const fetchUserData = async () => {
    try {
      setLoading(true);
      setError(null);
      
      const { data: { user }, error: userError } = await supabase.auth.getUser();

      if (userError) throw userError;
      
      if (!user) {
        setUser(null);
        setBookings([]);
        return;
      }

      // جلب البيانات بشكل متوازي
      const [profile, userBookings] = await Promise.all([
        getUserProfile(user.id).catch(() => null),
        getUserBookings(user.id).catch(() => [])
      ]);

      setUser({
        ...user,
        ...(profile || {}),
        avatar: profile?.avatar_url || 'https://randomuser.me/api/portraits/men/1.jpg',
      });
      
      setBookings(userBookings || []);
    } catch (error) {
      console.error('Profil yüklenirken hata:', error);
      setError(error.message);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchUserData();

    const { data: authListener } = supabase.auth.onAuthStateChange(async (event) => {
      if (event === 'SIGNED_OUT') {
        setUser(null);
        setBookings([]);
      } else if (event === 'SIGNED_IN') {
        fetchUserData();
      }
    });

  }, []);

  const handleRefresh = () => {
    setRefreshing(true);
    fetchUserData();
  };

  const handleLogout = async () => {
    try {
      setLoading(true);
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
      navigation.replace('GirisYap');
    } catch (error) {
      Alert.alert('Çıkış Hatası', error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateProfile = () => {
    navigation.navigate('ProfilDuzenle', {
      user,
      onSave: async (updatedData) => {
        try {
          setLoading(true);
          const { error } = await supabase
            .from('profiles')
            .update(updatedData)
            .eq('id', user.id);
            
          if (error) throw error;
          
          setUser(prev => ({ ...prev, ...updatedData }));
          Alert.alert('Başarılı', 'Profil bilgileri güncellendi');
        } catch (error) {
          Alert.alert('Hata', error.message);
        } finally {
          setLoading(false);
        }
      },
    });
  };

  if (loading && !refreshing) {
    return (
      <View style={[styles.container, styles.loadingContainer]}>
        <ActivityIndicator size="large" color="#4A6FA5" />
        <Text style={styles.loadingText}>Profil bilgileri yükleniyor...</Text>
      </View>
    );
  }

  if (error) {
    return (
      <View style={[styles.container, styles.errorContainer]}>
        <Ionicons name="warning" size={50} color="#F44336" />
        <Text style={styles.errorText}>Profil yüklenirken hata oluştu</Text>
        <Text style={styles.errorDetail}>{error}</Text>
        <TouchableOpacity 
          style={styles.retryButton} 
          onPress={handleRefresh}
        >
          <Text style={styles.retryButtonText}>Tekrar Dene</Text>
        </TouchableOpacity>
      </View>
    );
  }

  if (!user) {
    return (
      <View style={[styles.container, styles.noUserContainer]}>
        <Text style={styles.noUserText}>Kullanıcı girişi yapılmamış</Text>
        <TouchableOpacity 
          style={styles.loginButton} 
          onPress={() => navigation.navigate('GirisYap')}
        >
          <Text style={styles.loginButtonText}>Giriş Yap</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <ScrollView 
      style={styles.container}
      refreshControl={
        <RefreshControl
          refreshing={refreshing}
          onRefresh={handleRefresh}
          colors={['#4A6FA5']}
          tintColor="#4A6FA5"
        />
      }
    >
      {/* Profil Üst Kısım */}
      <LinearGradient colors={['#4A6FA5', '#3A5A80']} style={styles.profileHeader}>
        <View style={styles.avatarContainer}>
          <Image 
            source={{ uri: user.avatar }} 
            style={styles.avatar} 
            onError={() => setUser(prev => ({...prev, avatar: 'https://randomuser.me/api/portraits/men/1.jpg'}))}
          />
          <TouchableOpacity style={styles.editButton} onPress={handleUpdateProfile}>
            <Ionicons name="camera" size={20} color="#fff" />
          </TouchableOpacity>
        </View>
        <Text style={styles.userName}>{user.full_name || 'Kullanıcı Adı'}</Text>
        <Text style={styles.userEmail}>{user.email}</Text>
      </LinearGradient>

      {/* Kişisel Bilgiler */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Kişisel Bilgiler</Text>
        <View style={styles.infoItem}>
          <Ionicons name="person" size={20} color="#4A6FA5" />
          <Text style={styles.infoText}>{user.full_name || 'Belirtilmemiş'}</Text>
        </View>
        <View style={styles.infoItem}>
          <Ionicons name="mail" size={20} color="#4A6FA5" />
          <Text style={styles.infoText}>{user.email}</Text>
        </View>
        <View style={styles.infoItem}>
          <Ionicons name="call" size={20} color="#4A6FA5" />
          <Text style={styles.infoText}>{user.phone || 'Belirtilmemiş'}</Text>
        </View>
        <TouchableOpacity 
          style={styles.editProfileButton} 
          onPress={handleUpdateProfile}
          disabled={loading}
        >
          {loading ? (
            <ActivityIndicator color="#4A6FA5" />
          ) : (
            <Text style={styles.editProfileButtonText}>Profili Düzenle</Text>
          )}
        </TouchableOpacity>
      </View>

      {/* Rezervasyon Geçmişi */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Rezervasyon Geçmişi</Text>
        {bookings.length > 0 ? (
          bookings.map((booking) => (
            <TouchableOpacity
              key={booking.id}
              style={styles.bookingCard}
              onPress={() => !loading && navigation.navigate('RezervasyonDetay', { bookingId: booking.id })}
              disabled={loading}
            >
              <View style={styles.bookingInfo}>
                <Text style={styles.bookingTitle}>{booking.etkinlikler?.baslik || 'Etkinlik Başlığı Yok'}</Text>
                <Text style={styles.bookingDate}>
                  {booking.etkinlikler?.baslangic_tarihi 
                    ? new Date(booking.etkinlikler.baslangic_tarihi).toLocaleDateString('tr-TR') 
                    : 'Tarih Yok'}
                </Text>
                <View style={styles.bookingMeta}>
                  <Text style={styles.bookingTickets}>{booking.bilet_sayisi || 0} bilet</Text>
                  <Text style={styles.bookingTotal}>{booking.toplam_tutar || 0} TL</Text>
                </View>
                <Text style={styles.bookingLocation}>
                  {booking.etkinlikler?.mekanlar?.ad || 'Mekan Yok'}, {booking.etkinlikler?.mekanlar?.adres || 'Adres Yok'}
                </Text>
              </View>
              <View
                style={[
                  styles.bookingStatus,
                  {
                    backgroundColor: booking.durum === 'Onaylandı' ? '#4CAF50' : '#F44336',
                  },
                ]}
              >
                <Text style={styles.bookingStatusText}>{booking.durum || 'Durum Yok'}</Text>
              </View>
            </TouchableOpacity>
          ))
        ) : (
          <View style={styles.noBookings}>
            <Ionicons name="calendar" size={40} color="#ccc" />
            <Text style={styles.noBookingsText}>Henüz rezervasyonunuz yok</Text>
          </View>
        )}
      </View>

      {/* Çıkış Butonu */}
      <TouchableOpacity 
        style={styles.logoutButton} 
        onPress={handleLogout}
        disabled={loading}
      >
        {loading ? (
          <ActivityIndicator color="#F44336" />
        ) : (
          <>
            <Ionicons name="log-out" size={24} color="#F44336" />
            <Text style={styles.logoutButtonText}>Çıkış Yap</Text>
          </>
        )}
      </TouchableOpacity>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
  },
  loadingText: {
    marginTop: 20,
    fontSize: 16,
    color: '#4A6FA5',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#f5f5f5',
  },
  errorText: {
    fontSize: 18,
    color: '#F44336',
    marginTop: 10,
    fontWeight: 'bold',
  },
  errorDetail: {
    fontSize: 14,
    color: '#777',
    marginTop: 5,
    textAlign: 'center',
  },
  retryButton: {
    marginTop: 20,
    backgroundColor: '#4A6FA5',
    padding: 12,
    borderRadius: 8,
    width: '60%',
    alignItems: 'center',
  },
  retryButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  noUserContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  noUserText: {
    fontSize: 18,
    color: '#555',
    marginBottom: 20,
  },
  loginButton: {
    backgroundColor: '#4A6FA5',
    padding: 15,
    borderRadius: 8,
    width: '60%',
    alignItems: 'center',
  },
  loginButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  profileHeader: {
    padding: 20,
    alignItems: 'center',
    paddingBottom: 40,
  },
  avatarContainer: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 15,
    position: 'relative',
  },
  avatar: {
    width: 110,
    height: 110,
    borderRadius: 55,
  },
  editButton: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    backgroundColor: '#4A6FA5',
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#fff',
  },
  userName: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
    marginTop: 10,
  },
  userEmail: {
    fontSize: 16,
    color: 'rgba(255,255,255,0.8)',
    marginTop: 5,
  },
  section: {
    backgroundColor: '#fff',
    borderRadius: 15,
    padding: 20,
    margin: 15,
    marginTop: -30,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 3,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
    paddingBottom: 10,
  },
  infoItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
  },
  infoText: {
    fontSize: 16,
    marginLeft: 10,
    color: '#555',
  },
  editProfileButton: {
    borderWidth: 1,
    borderColor: '#4A6FA5',
    borderRadius: 10,
    padding: 12,
    alignItems: 'center',
    marginTop: 10,
  },
  editProfileButtonText: {
    color: '#4A6FA5',
    fontSize: 16,
    fontWeight: 'bold',
  },
  bookingCard: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#f9f9f9',
    borderRadius: 10,
    padding: 15,
    marginBottom: 10,
  },
  bookingInfo: {
    flex: 1,
  },
  bookingTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  bookingDate: {
    fontSize: 14,
    color: '#777',
    marginVertical: 5,
  },
  bookingMeta: {
    flexDirection: 'row',
  },
  bookingTickets: {
    fontSize: 14,
    color: '#4A6FA5',
    marginRight: 15,
  },
  bookingTotal: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#333',
  },
  bookingLocation: {
    fontSize: 13,
    color: '#666',
    marginTop: 5,
  },
  bookingStatus: {
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 15,
  },
  bookingStatusText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: 'bold',
  },
  noBookings: {
    alignItems: 'center',
    padding: 20,
  },
  noBookingsText: {
    fontSize: 16,
    color: '#999',
    marginTop: 10,
  },
  logoutButton: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 15,
    margin: 15,
  },
  logoutButtonText: {
    color: '#F44336',
    fontSize: 16,
    fontWeight: 'bold',
    marginLeft: 10,
  },
});

export default Profil;