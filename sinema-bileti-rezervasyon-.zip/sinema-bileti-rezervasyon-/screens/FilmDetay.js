import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, StyleSheet, Image, TouchableOpacity, Linking } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { supabase } from '../lib/supabase';

const FilmDetay = ({ navigation, route }) => {
  const { filmId } = route.params;
  const [film, setFilm] = useState(null);
  const [seanslar, setSeanslar] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isFavorite, setIsFavorite] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        
        // Film detaylarını getir
        const { data: filmData, error: filmError } = await supabase
          .from('filmler')
          .select('*')
          .eq('id', filmId)
          .single();

        if (filmError || !filmData) throw filmError || new Error('Film bulunamadı');
        setFilm(filmData);

        // Seansları getir
        const { data: seansData, error: seansError } = await supabase
          .from('seanslar')
          .select('*, salonlar(*, mekanlar(*))')
          .eq('film_id', filmId)
          .gte('baslangic', new Date().toISOString())
          .order('baslangic');

        if (seansError) throw seansError;
        setSeanslar(seansData);

        // Favori durumunu kontrol et
        const { data: { user } } = await supabase.auth.getUser();
        if (user) {
          const { data: favoriteData, error: favoriteError } = await supabase
            .from('favoriler')
            .select('*')
            .eq('kullanici_id', user.id)
            .eq('film_id', filmId)
            .maybeSingle();

          if (!favoriteError && favoriteData) {
            setIsFavorite(favoriteData.is_favorite);
          }
        }

      } catch (err) {
        console.error('Hata:', err);
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [filmId]);

  const toggleFavorite = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        navigation.navigate('GirisYap');
        return;
      }

      const newFavoriteStatus = !isFavorite;
      setIsFavorite(newFavoriteStatus);

      // Supabase'de favori durumunu güncelle
      await supabase.from('favoriler').upsert({
        kullanici_id: user.id,
        film_id: filmId,
        is_favorite: newFavoriteStatus
      });

    } catch (error) {
      console.error('Favori hatası:', error);
      setIsFavorite(!isFavorite); // Rollback
    }
  };

  const handleSeansSec = (seansId) => {
    navigation.navigate('SeansSec', { seansId });
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <Text>Yükleniyor...</Text>
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.errorContainer}>
        <Text style={styles.errorText}>{error}</Text>
      </View>
    );
  }

  if (!film) {
    return (
      <View style={styles.errorContainer}>
        <Text style={styles.errorText}>Film bilgileri yüklenemedi</Text>
      </View>
    );
  }

  const handleRezervasyon = () => {
    
    navigation.navigate('Rezervasyon') 
     
  };
  return (
    <ScrollView style={styles.container}>
      <Image source={{ uri: film.afis_url }} style={styles.afis} />
      
      <View style={styles.icerik}>
        <View style={styles.baslikContainer}>
          <Text style={styles.filmAd}>{film.ad}</Text>
          <TouchableOpacity onPress={toggleFavorite}>
            <Ionicons 
              name={isFavorite ? "heart" : "heart-outline"} 
              size={28} 
              color={isFavorite ? "#FF5252" : "#4A6FA5"} 
            />
          </TouchableOpacity>
        </View>
        
        <View style={styles.metaBilgiler}>
          <View style={styles.metaItem}>
            <Ionicons name="star" size={16} color="#FFD700" />
            <Text style={styles.metaText}>IMDB: {film.imdb_puan}</Text>
          </View>
          <View style={styles.metaItem}>
            <Ionicons name="time" size={16} color="#4A6FA5" />
            <Text style={styles.metaText}>{film.sure} dakika</Text>
          </View>
          <View style={styles.metaItem}>
            <Ionicons name="alert-circle" size={16} color="#4A6FA5" />
            <Text style={styles.metaText}>+{film.yas_siniri}</Text>
          </View>
          <View style={styles.metaItem}>
            <Ionicons name="film" size={16} color="#4A6FA5" />
            <Text style={styles.metaText}>{film.tur}</Text>
          </View>
        </View>

        <Text style={styles.bolumBaslik}>Özet</Text>
        <Text style={styles.aciklama}>{film.aciklama}</Text>

        <Text style={styles.bolumBaslik}>Yönetmen</Text>
        <Text style={styles.yonetmen}>{film.yonetmen}</Text>

        <Text style={styles.bolumBaslik}>Oyuncular</Text>
        <Text style={styles.oyuncular}>{film.oyuncular}</Text>

        <Text style={styles.bolumBaslik}>Seanslar</Text>
        {seanslar.length > 0 ? (
          seanslar.map(seans => (
            <TouchableOpacity 
              key={seans.id}
              style={styles.seansKarti}
              onPress={() => handleSeansSec(seans.id)}
            >
              <View style={styles.seansBilgi}>
                <Text style={styles.seansTarih}>
                  {new Date(seans.baslangic).toLocaleDateString('tr-TR', {
                    day: 'numeric',
                    month: 'long',
                    weekday: 'long'
                  })}
                </Text>
                <Text style={styles.seansSaat}>
                  {new Date(seans.baslangic).toLocaleTimeString('tr-TR', {
                    hour: '2-digit',
                    minute: '2-digit'
                  })}
                </Text>
                <Text style={styles.seansMekan}>
                  {seans.salonlar.mekanlar.ad} - {seans.salonlar.ad}
                </Text>
                <Text style={styles.seansFormat}>
                  {seans.format} • {seans.dil}
                </Text>
              </View>
              <View style={styles.seansFiyatContainer}>
                <Text style={styles.seansFiyat}>{seans.fiyat} TL</Text>
                <Ionicons name="chevron-forward" size={20} color="#4A6FA5" />
              </View>
            </TouchableOpacity>
          ))
        ) : (
          <Text style={styles.bosSeans}>Bu film için seans bulunamadı</Text>
        )}
      </View>
       <TouchableOpacity 
          style={styles.rezervasyonButon}
          onPress={handleRezervasyon}
        >
          <Text style={styles.rezervasyonButonMetin}>Rezervasyon Yap</Text>
        </TouchableOpacity>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  errorText: {
    color: '#FF5252',
    fontSize: 16,
  },
  afis: {
    width: '100%',
    height: 300,
  },
  icerik: {
    padding: 20,
  },
  baslikContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
  },
  filmAd: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    flex: 1,
  },
  metaBilgiler: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginBottom: 20,
  },
  metaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 20,
    marginBottom: 10,
  },
  metaText: {
    marginLeft: 5,
    fontSize: 14,
    color: '#666',
  },
  bolumBaslik: {
    fontSize: 18,
    fontWeight: 'bold',
    marginTop: 20,
    marginBottom: 10,
    color: '#333',
  },
  aciklama: {
    fontSize: 16,
    lineHeight: 24,
    color: '#333',
  },
  yonetmen: {
    fontSize: 16,
    color: '#333',
  },
  oyuncular: {
    fontSize: 16,
    color: '#333',
    fontStyle: 'italic',
  },
  seansKarti: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  seansBilgi: {
    flex: 1,
  },
  seansTarih: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  seansSaat: {
    fontSize: 14,
    color: '#666',
    marginTop: 5,
  },
  seansMekan: {
    fontSize: 14,
    color: '#666',
    marginTop: 5,
  },
  seansFormat: {
    fontSize: 12,
    color: '#999',
    marginTop: 5,
  },
  seansFiyatContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  seansFiyat: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#4A6FA5',
    marginRight: 5,
  },
  bosSeans: {
    fontSize: 16,
    color: '#999',
    textAlign: 'center',
    padding: 20,
  },
    rezervasyonButon: {
    backgroundColor: '#4A6FA5',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 3,
  },
  rezervasyonButonMetin: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default FilmDetay;