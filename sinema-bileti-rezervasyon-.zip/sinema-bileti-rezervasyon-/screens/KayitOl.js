import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image, ScrollView, TextInput } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '../lib/supabase';

const KayitOl = ({ navigation }) => {
  const [form, setForm] = useState({
    ad: '',
    soyad: '',
    email: '',
    sifre: '',
    sifreTekrar: ''
  });
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const validate = () => {
    const newErrors = {};
    
    if (!form.ad) newErrors.ad = 'Ad zorunlu';
    if (!form.soyad) newErrors.soyad = 'Soyad zorunlu';
    
    if (!form.email) {
      newErrors.email = 'E-posta zorunlu';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
      newErrors.email = 'Geçersiz e-posta';
    }
    
    if (!form.sifre) {
      newErrors.sifre = 'Şifre zorunlu';
    } else if (form.sifre.length < 6) {
      newErrors.sifre = 'Şifre en az 6 karakter olmalı';
    }
    
    if (form.sifre !== form.sifreTekrar) {
      newErrors.sifreTekrar = 'Şifreler eşleşmiyor';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async () => {
    if (!validate()) return;
    
    setLoading(true);
    try {
      const { data, error } = await supabase.auth.signUp({
        email: form.email,
        password: form.sifre,
        options: {
          data: {
            ad: form.ad,
            soyad: form.soyad,
          }
        }
      });

      if (error) throw error;
      setSuccess(true);
    } catch (error) {
      setErrors({ general: error.message });
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <LinearGradient colors={['#4A6FA5', '#3A5A80']} style={styles.container}>
        <View style={styles.successContainer}>
          <Ionicons name="checkmark-circle" size={80} color="#4CAF50" />
          <Text style={styles.successTitle}>Kayıt Başarılı!</Text>
          <Text style={styles.successText}>
            E-posta adresinize doğrulama bağlantısı gönderildi. Lütfen e-postanızı kontrol edin.
          </Text>
          <TouchableOpacity 
            style={styles.button}
            onPress={() => navigation.navigate('GirisYap')}
          >
            <Text style={styles.buttonText}>Giriş Yap</Text>
          </TouchableOpacity>
        </View>
      </LinearGradient>
    );
  }

  return (
    <LinearGradient colors={['#4A6FA5', '#3A5A80']} style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <Image 
          source={{ uri: 'https://via.placeholder.com/100' }} 
          style={styles.logo} 
        />
        
        <Text style={styles.title}>Yeni Hesap Oluştur</Text>
        <Text style={styles.subtitle}>Etkinlikleri keşfetmeye başlamak için kayıt olun</Text>
        
        <View style={styles.formContainer}>
          {errors.general && (
            <Text style={styles.errorText}>{errors.general}</Text>
          )}

          <View style={styles.inputRow}>
            <View style={[styles.inputContainer, { flex: 1, marginRight: 10 }]}>
              <TextInput
                style={styles.input}
                placeholder="Ad"
                value={form.ad}
                onChangeText={(text) => setForm({...form, ad: text})}
              />
              {errors.ad && <Text style={styles.errorText}>{errors.ad}</Text>}
            </View>

            <View style={[styles.inputContainer, { flex: 1 }]}>
              <TextInput
                style={styles.input}
                placeholder="Soyad"
                value={form.soyad}
                onChangeText={(text) => setForm({...form, soyad: text})}
              />
              {errors.soyad && <Text style={styles.errorText}>{errors.soyad}</Text>}
            </View>
          </View>

          <View style={styles.inputContainer}>
            <Ionicons name="mail" size={20} color="#666" style={styles.icon} />
            <TextInput
              style={styles.input}
              placeholder="E-posta"
              keyboardType="email-address"
              autoCapitalize="none"
              value={form.email}
              onChangeText={(text) => setForm({...form, email: text})}
            />
          </View>
          {errors.email && <Text style={styles.errorText}>{errors.email}</Text>}

          <View style={styles.inputContainer}>
            <Ionicons name="lock-closed" size={20} color="#666" style={styles.icon} />
            <TextInput
              style={styles.input}
              placeholder="Şifre (en az 6 karakter)"
              secureTextEntry
              value={form.sifre}
              onChangeText={(text) => setForm({...form, sifre: text})}
            />
          </View>
          {errors.sifre && <Text style={styles.errorText}>{errors.sifre}</Text>}

          <View style={styles.inputContainer}>
            <Ionicons name="lock-closed" size={20} color="#666" style={styles.icon} />
            <TextInput
              style={styles.input}
              placeholder="Şifre Tekrar"
              secureTextEntry
              value={form.sifreTekrar}
              onChangeText={(text) => setForm({...form, sifreTekrar: text})}
            />
          </View>
          {errors.sifreTekrar && <Text style={styles.errorText}>{errors.sifreTekrar}</Text>}

          <TouchableOpacity 
            style={styles.primaryButton}
            onPress={handleSubmit}
            disabled={loading}
          >
            <Text style={styles.buttonText}>
              {loading ? 'Kayıt Olunuyor...' : 'Kayıt Ol'}
            </Text>
          </TouchableOpacity>

          <View style={styles.divider}>
            <View style={styles.dividerLine} />
            <Text style={styles.dividerText}>Zaten hesabınız var mı?</Text>
            <View style={styles.dividerLine} />
          </View>

          <TouchableOpacity 
            style={styles.secondaryButton}
            onPress={() => navigation.navigate('GirisYap')}
          >
            <Text style={styles.secondaryButtonText}>Giriş Yap</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContainer: {
    flexGrow: 1,
    padding: 20,
    justifyContent: 'center',
  },
  logo: {
    width: 100,
    height: 100,
    alignSelf: 'center',
    marginBottom: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#fff',
    textAlign: 'center',
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 16,
    color: 'rgba(255,255,255,0.8)',
    textAlign: 'center',
    marginBottom: 40,
  },
  formContainer: {
    backgroundColor: '#fff',
    borderRadius: 15,
    padding: 25,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 5 },
    shadowOpacity: 0.2,
    shadowRadius: 10,
    elevation: 5,
  },
  inputRow: {
    flexDirection: 'row',
    marginBottom: 15,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 10,
    paddingHorizontal: 15,
    backgroundColor: '#f9f9f9',
    marginBottom: 15,
  },
  icon: {
    marginRight: 10,
  },
  input: {
    flex: 1,
    height: 50,
    color: '#333',
  },
  errorText: {
    color: '#e74c3c',
    fontSize: 12,
    marginBottom: 10,
    marginLeft: 5,
  },
  primaryButton: {
    backgroundColor: '#4A6FA5',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 10,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  divider: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 20,
  },
  dividerLine: {
    flex: 1,
    height: 1,
    backgroundColor: '#ddd',
  },
  dividerText: {
    color: '#999',
    marginHorizontal: 10,
    fontSize: 14,
  },
  secondaryButton: {
    borderWidth: 1,
    borderColor: '#4A6FA5',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
  },
  secondaryButtonText: {
    color: '#4A6FA5',
    fontSize: 16,
    fontWeight: 'bold',
  },
  successContainer: {
    backgroundColor: '#fff',
    borderRadius: 15,
    padding: 30,
    margin: 20,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 5 },
    shadowOpacity: 0.2,
    shadowRadius: 10,
    elevation: 5,
  },
  successTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#4A6FA5',
    marginVertical: 15,
    textAlign: 'center',
  },
  successText: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
    marginBottom: 20,
  },
  button: {
    backgroundColor: '#4A6FA5',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
    width: '100%',
  },
});

export default KayitOl;