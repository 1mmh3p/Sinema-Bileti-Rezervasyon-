import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, TextInput, Alert, ActivityIndicator } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { supabase } from '../lib/supabase';

const Rezervasyon = ({ navigation, route }) => {
  // معالجة المعلمات مع تحقق مكثف
  const params = route.params || {};
  const [etkinlikId, setEtkinlikId] = useState(() => {
    const id = params.etkinlikId;
    return id ? Number(id) : null;
  });
  const [etkinlikFiyat, setEtkinlikFiyat] = useState(() => {
    const fiyat = params.etkinlikFiyat;
    return fiyat ? Number(fiyat) : 0;
  });
  const etkinlikBaslik = params.etkinlikBaslik || 'Etkinlik';
  const mekanAd = params.mekanAd || 'Mekan';

  const [seats, setSeats] = useState(['A1', 'A2']);
  const [biletSayisi, setBiletSayisi] = useState(seats.length);
  const [kartNumarasi, setKartNumarasi] = useState('');
  const [kartSahibi, setKartSahibi] = useState('');
  const [sonKullanma, setSonKullanma] = useState('');
  const [cvv, setCvv] = useState('');
  const [loading, setLoading] = useState(false);
  const [user, setUser] = useState(null);

  // حساب المبلغ الإجمالي مع تحقق
  const toplamTutar = biletSayisi * (etkinlikFiyat || 0);

  useEffect(() => {
    console.log('Route Params:', route.params);
    
    const fetchUserAndVerify = async () => {
      try {
        const { data: { user }, error } = await supabase.auth.getUser();
        
        if (error || !user) {
          Alert.alert('Hata', 'Oturum açılması gerekiyor');
          navigation.navigate('Giris');
          return;
        }

        // التحقق من وجود المستخدم في جدول kullanicilar
        const { data: kullanici, error: kullaniciError } = await supabase
          .from('kullanicilar')
          .select('*')
          .eq('id', user.id)
          .single();

        if (kullaniciError || !kullanici) {
          // إذا لم يوجد المستخدم، ننشئه
          const { error: createError } = await supabase
            .from('kullanicilar')
            .insert([{ id: user.id }]);
            
          if (createError) throw createError;
        }

        setUser(user);
      } catch (err) {
        console.error('Kullanıcı doğrulama hatası:', err);
        Alert.alert('Hata', 'Kullanıcı bilgileri yüklenemedi');
        navigation.goBack();
      }
    };

    fetchUserAndVerify();
  }, []);

  const handleRezervasyon = async () => {
    if (!etkinlikId) {
      Alert.alert('Hata', 'Geçersiz etkinlik bilgisi');
      return;
    }

    if (!user?.id) {
      Alert.alert('Hata', 'Kullanıcı doğrulanamadı');
      return;
    }

    // ... باقي التحققات

    setLoading(true);
    try {
      const biletKodu = `BLT-${Date.now().toString(36).toUpperCase()}`;
      const koltuklarJson = JSON.stringify(seats);

      const { data, error } = await supabase
        .from('rezervasyonlar')
        .insert([{
          kullanici_id: user.id,
          seans_id: etkinlikId,
          koltuklar: koltuklarJson,
          adet: biletSayisi,
          toplam_tutar: toplamTutar,
          odeme_durumu: 'bekliyor',
          odeme_yontemi: 'kredi kartı',
          bilet_kodu: biletKodu
        }])
        .select();

      if (error) throw error;

      Alert.alert(
        'Başarılı',
        `Rezervasyon #${data[0].id}\nBilet Kodunuz: ${biletKodu}`,
        [{ text: 'Tamam', onPress: () => navigation.navigate('Profil') }]
      );
    } catch (err) {
      console.error('Rezervasyon Hatası:', {
        error: err,
        user: user?.id,
        seans: etkinlikId,
        fiyat: etkinlikFiyat
      });
      
      let errorMessage = 'Rezervasyon işlemi başarısız oldu';
      if (err.code === '23503') {
        errorMessage = 'Kullanıcı veya seans bilgisi geçersiz';
      }

      Alert.alert('Hata', errorMessage);
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView style={styles.container}>
      {/* شريط العنوان */}
      <LinearGradient colors={['#4A6FA5', '#3A5A80']} style={styles.header}>
        <Text style={styles.headerTitle}>Rezervasyon</Text>
      </LinearGradient>

      <View style={styles.content}>
        {/* معلومات التصحيح */}
        <View style={styles.debugBox}>
          <Text style={styles.debugText}>Seans ID: {etkinlikId || 'Yok'}</Text>
          <Text style={styles.debugText}>Fiyat: {etkinlikFiyat} TL</Text>
          <Text style={styles.debugText}>Kullanıcı ID: {user?.id || 'Yok'}</Text>
        </View>

        {/* اختيار عدد التذاكر */}
        <View style={styles.biletSecim}>
          <Text style={styles.sectionTitle}>Bilet Sayısı</Text>
          <View style={styles.biletSayiContainer}>
            <TouchableOpacity
              style={[styles.sayiButton, biletSayisi <= 1 && styles.disabledButton]}
              onPress={() => setBiletSayisi(Math.max(1, biletSayisi - 1))}
              disabled={biletSayisi <= 1}
            >
              <Ionicons name="remove" size={20} color="#4A6FA5" />
            </TouchableOpacity>

            <Text style={styles.biletSayi}>{biletSayisi}</Text>

            <TouchableOpacity
              style={styles.sayiButton}
              onPress={() => setBiletSayisi(biletSayisi + 1)}
            >
              <Ionicons name="add" size={20} color="#4A6FA5" />
            </TouchableOpacity>
          </View>
        </View>

        {/* المقاعد المختارة */}
        <Text style={styles.koltuklarText}>Seçilen Koltuklar: {seats.join(', ') || 'Henüz seçilmedi'}</Text>

        {/* معلومات الدفع */}
        <View style={styles.odemeBilgileri}>
          <Text style={styles.sectionTitle}>Ödeme Bilgileri</Text>

          <Text style={styles.inputLabel}>Kart Numarası</Text>
          <TextInput
            style={styles.input}
            placeholder="1234 5678 9012 3456"
            keyboardType="numeric"
            value={kartNumarasi}
            onChangeText={text => setKartNumarasi(text.replace(/[^0-9]/g, ''))}
            maxLength={16}
          />

          <Text style={styles.inputLabel}>Kart Sahibi</Text>
          <TextInput
            style={styles.input}
            placeholder="Ad Soyad"
            value={kartSahibi}
            onChangeText={setKartSahibi}
          />

          <View style={styles.row}>
            <View style={styles.halfInputContainer}>
              <Text style={styles.inputLabel}>Son Kullanma (AA/YY)</Text>
              <TextInput
                style={styles.input}
                placeholder="MM/YY"
                value={sonKullanma}
                onChangeText={text => {
                  if (text.length === 2 && !text.includes('/')) {
                    setSonKullanma(`${text}/`);
                  } else {
                    setSonKullanma(text);
                  }
                }}
                maxLength={5}
              />
            </View>
            <View style={styles.halfInputContainer}>
              <Text style={styles.inputLabel}>CVV</Text>
              <TextInput
                style={styles.input}
                placeholder="123"
                keyboardType="numeric"
                secureTextEntry
                value={cvv}
                onChangeText={text => setCvv(text.replace(/[^0-9]/g, ''))}
                maxLength={3}
              />
            </View>
          </View>
        </View>

        {/* المبلغ الإجمالي */}
        <View style={styles.toplamContainer}>
          <View style={styles.toplamRow}>
            <Text style={styles.toplamLabel}>Toplam:</Text>
            <Text style={styles.toplamTutar}>{toplamTutar} TL</Text>
          </View>
        </View>

        {/* زر التأكيد */}
        <TouchableOpacity
          style={[styles.onaylaButton, loading && styles.disabledButton]}
          onPress={handleRezervasyon}
          disabled={loading}
        >
          {loading ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <>
              <Ionicons name="card" size={20} color="#fff" />
              <Text style={{ color: 'red', textAlign: 'center' }}>
        Etkinlik Fiyatı: {etkinlikFiyat} TL 
      </Text>
            </>
          )}
        </TouchableOpacity>

        {/* رسالة الدفع الآمن */}
        <View style={styles.guvenliOdeme}>
          <Ionicons name="shield-checkmark" size={20} color="#4CAF50" />
          <Text style={styles.guvenliOdemeText}> Güvenli Ödeme</Text>
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f5f5f5' },
  header: {
    padding: 20,
    paddingTop: 50,
    paddingBottom: 30,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
    textAlign: 'center'
  },
  content: {
    flex: 1,
    marginTop: -20,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    backgroundColor: '#fff',
    padding: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 15,
    color: '#000',
  },
  biletSecim: {
    marginBottom: 20,
  },
  biletSayiContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: 150,
  },
  sayiButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#4A6FA5',
    justifyContent: 'center',
    alignItems: 'center',
  },
  disabledButton: {
    opacity: 0.5
  },
  biletSayi: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#000',
  },
  koltuklarText: {
    marginBottom: 20,
    color: '#666',
    fontSize: 16
  },
  odemeBilgileri: {
    marginBottom: 20,
  },
  inputLabel: {
    fontSize: 16,
    marginBottom: 8,
    color: '#555'
  },
  input: {
    height: 50,
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    paddingHorizontal: 15,
    marginBottom: 15,
    fontSize: 16,
    backgroundColor: '#f9f9f9'
  },
  row: { 
    flexDirection: 'row', 
    justifyContent: 'space-between' 
  },
  halfInputContainer: { 
    width: '48%' 
  },
  toplamContainer: {
    marginTop: 20,
    paddingTop: 15,
    borderTopWidth: 1,
    borderTopColor: '#f0f0f0',
  },
  toplamRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  toplamLabel: {
    fontSize: 16,
    color: '#666',
  },
  toplamTutar: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#4A6FA5',
  },
  onaylaButton: {
    backgroundColor: '#4A6FA5',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 20,
    flexDirection: 'row',
    justifyContent: 'center',
  },
  onaylaButtonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
    marginLeft: 10
  },
  guvenliOdeme: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 15,
  },
  guvenliOdemeText: {
    color: '#4CAF50',
    fontSize: 14,
  },
});

export default Rezervasyon;