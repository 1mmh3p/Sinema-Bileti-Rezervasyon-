import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, Image, FlatList, ActivityIndicator } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { supabase } from '../lib/supabase';

const Filmler = ({ navigation, route }) => {
  const [loading, setLoading] = useState(true);
  const [filmler, setFilmler] = useState([]);
  const [sehirler, setSehirler] = useState([]);
  const [seciliTur, setSeciliTur] = useState('Tümü');
  const [seciliSehir, setSeciliSehir] = useState(null);
  const [favoriler, setFavoriler] = useState([]);

  // Film türleri
  const turler = ['Tümü', 'Aksiyon', 'Dram', 'Komedi', 'Bilim Kurgu', 'Korku', 'Romantik', 'Animasyon'];

  // Verileri yükle
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        
        // Şehirleri yükle
        const { data: sehirData, error: sehirError } = await supabase
          .from('iller')
          .select('*')
          .order('plaka_kodu', { ascending: true });
        
        if (sehirError) throw sehirError;
        setSehirler(sehirData);

        // Filmleri yükle
        const { data: filmData, error: filmError } = await supabase
          .from('filmler')
          .select('*')
          .order('vizyon_tarihi', { ascending: false });
        
        if (filmError) throw filmError;
        setFilmler(filmData);

      } catch (error) {
        console.error('Veri yükleme hatası:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  // Favori durumunu güncelle
  const toggleFavori = async (filmId) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        navigation.navigate('GirisYap');
        return;
      }

      const isFavori = favoriler.includes(filmId);
      let newFavoriler;

      if (isFavori) {
        newFavoriler = favoriler.filter(id => id !== filmId);
      } else {
        newFavoriler = [...favoriler, filmId];
      }

      setFavoriler(newFavoriler);

      // Supabase'de favori durumunu güncelle
      await supabase.from('favoriler').upsert({
        kullanici_id: user.id,
        film_id: filmId,
        is_favorite: !isFavori
      });
      
    } catch (error) {
      console.error('Favori hatası:', error);
    }
  };

  // Filtreleme fonksiyonu
  const filtrelenmisFilmler = filmler.filter(film => {
    const turFiltre = seciliTur === 'Tümü' || film.tur === seciliTur;
    return turFiltre;
  });

  // Film kartı bileşeni
  const renderFilm = ({ item }) => (
    <TouchableOpacity
      style={styles.filmKarti}
      onPress={() => navigation.navigate('FilmDetay', { filmId: item.id })}
    >
      <Image 
        source={{ uri: item.afis_url || 'https://via.placeholder.com/300' }} 
        style={styles.filmResim} 
      />
      
      <View style={styles.filmBilgi}>
        <View style={styles.filmBaslikContainer}>
          <Text style={styles.filmBaslik} numberOfLines={1}>{item.ad}</Text>
          <TouchableOpacity onPress={() => toggleFavori(item.id)}>
            <Ionicons 
              name={favoriler.includes(item.id) ? "heart" : "heart-outline"} 
              size={24} 
              color={favoriler.includes(item.id) ? "#FF5252" : "#ccc"} 
            />
          </TouchableOpacity>
        </View>
        
        <View style={styles.filmMeta}>
          <Ionicons name="star" size={16} color="#FFD700" />
          <Text style={styles.filmPuan}>
            IMDB: {item.imdb_puan}
          </Text>
        </View>
        
        <View style={styles.filmMeta}>
          <Ionicons name="time" size={16} color="#4A6FA5" />
          <Text style={styles.filmSure}>{item.sure} dakika</Text>
        </View>
        
        <View style={styles.filmFooter}>
          <View style={styles.turPil}>
            <Text style={styles.turPilText}>{item.tur}</Text>
          </View>
          <Text style={styles.yasSiniri}>+{item.yas_siniri}</Text>
        </View>
      </View>
    </TouchableOpacity>
  );

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#4A6FA5" />
        <Text style={styles.loadingText}>Filmler yükleniyor...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* Başlık ve Arama */}
      <LinearGradient
        colors={['#4A6FA5', '#3A5A80']}
        style={styles.header}
      >
        <Text style={styles.baslik}>Vizyondaki Filmler</Text>
        <TouchableOpacity 
          style={styles.aramaButon}
          onPress={() => navigation.navigate('FilmAra')}
        >
          <Ionicons name="search" size={24} color="#fff" />
        </TouchableOpacity>
      </LinearGradient>

      {/* Şehir Filtresi */}
      <ScrollView 
        horizontal 
        showsHorizontalScrollIndicator={false}
        style={styles.filtreContainer}
      >
        <TouchableOpacity
          style={[styles.filtreItem, !seciliSehir && styles.filtreItemAktif]}
          onPress={() => setSeciliSehir(null)}
        >
          <Text style={[styles.filtreText, !seciliSehir && styles.filtreTextAktif]}>Tüm Şehirler</Text>
        </TouchableOpacity>
        
        {sehirler.map((sehir) => (
          <TouchableOpacity
            key={sehir.id}
            style={[styles.filtreItem, seciliSehir === sehir.id && styles.filtreItemAktif]}
            onPress={() => setSeciliSehir(sehir.id)}
          >
            <Text style={[styles.filtreText, seciliSehir === sehir.id && styles.filtreTextAktif]}>
              {sehir.ad}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Tür Filtresi */}
      <ScrollView 
        horizontal 
        showsHorizontalScrollIndicator={false}
        style={styles.turContainer}
      >
        {turler.map((tur) => (
          <TouchableOpacity
            key={tur}
            style={[styles.turItem, seciliTur === tur && styles.turItemAktif]}
            onPress={() => setSeciliTur(tur)}
          >
            <Text style={[styles.turText, seciliTur === tur && styles.turTextAktif]}>
              {tur}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Film Listesi */}
      <FlatList
        data={filtrelenmisFilmler}
        renderItem={renderFilm}
        keyExtractor={item => item.id.toString()}
        contentContainerStyle={styles.filmListe}
        ListEmptyComponent={
          <View style={styles.bosListe}>
            <Ionicons name="film" size={48} color="#ccc" />
            <Text style={styles.bosListeText}>Filtrelerinize uygun film bulunamadı</Text>
            <TouchableOpacity
              style={styles.filtreleriSifirla}
              onPress={() => {
                setSeciliTur('Tümü');
                setSeciliSehir(null);
              }}
            >
              <Text style={styles.filtreleriSifirlaText}>Filtreleri Sıfırla</Text>
            </TouchableOpacity>
          </View>
        }
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  header: {
    padding: 20,
    paddingTop: 50,
    paddingBottom: 20,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  baslik: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
  },
  aramaButon: {
    padding: 8,
  },
  filtreContainer: {
    paddingVertical: 10,
    paddingHorizontal: 15,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  filtreItem: {
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: '#f5f5f5',
    marginRight: 10,
  },
  filtreItemAktif: {
    backgroundColor: '#4A6FA5',
  },
  filtreText: {
    color: '#666',
    fontWeight: '500',
  },
  filtreTextAktif: {
    color: '#fff',
  },
  turContainer: {
    padding: 15,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  turItem: {
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 20,
    backgroundColor: '#f5f5f5',
    marginRight: 10,
  },
  turItemAktif: {
    backgroundColor: '#4A6FA5',
  },
  turText: {
    color: '#666',
    fontWeight: '500',
  },
  turTextAktif: {
    color: '#fff',
  },
  filmListe: {
    padding: 15,
  },
  filmKarti: {
    backgroundColor: '#fff',
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  filmResim: {
    width: '100%',
    height: 200,
  },
  filmBilgi: {
    padding: 15,
  },
  filmBaslikContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  filmBaslik: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    flex: 1,
    marginRight: 10,
  },
  filmMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  filmPuan: {
    fontSize: 14,
    color: '#666',
    marginLeft: 5,
  },
  filmSure: {
    fontSize: 14,
    color: '#666',
    marginLeft: 5,
  },
  filmFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 10,
  },
  turPil: {
    backgroundColor: '#f0f4ff',
    borderRadius: 15,
    paddingHorizontal: 12,
    paddingVertical: 5,
  },
  turPilText: {
    color: '#4A6FA5',
    fontSize: 12,
    fontWeight: '500',
  },
  yasSiniri: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#FF5252',
  },
  bosListe: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 50,
  },
  bosListeText: {
    fontSize: 16,
    color: '#999',
    marginTop: 15,
    textAlign: 'center',
  },
  filtreleriSifirla: {
    marginTop: 20,
    padding: 10,
    backgroundColor: '#4A6FA5',
    borderRadius: 10,
  },
  filtreleriSifirlaText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: 'bold',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 10,
    fontSize: 16,
    color: '#4A6FA5',
  },
});

export default Filmler;