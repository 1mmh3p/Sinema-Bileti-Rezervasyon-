import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { supabase } from '../lib/supabase';

const SeansSec = ({ navigation, route }) => {
  // seansId'yi güvenli şekilde al
  const seansIdParam = route.params?.seansId;
  const seansId = Number(seansIdParam);

  // seansId geçerli değilse, uyar ve geri dön
  useEffect(() => {
    if (isNaN(seansId)) {
      Alert.alert('Hata', 'Geçersiz seans kimliği');
      navigation.goBack();
    }
  }, [seansId]);

  const [seans, setSeans] = useState(null);
  const [film, setFilm] = useState(null);
  const [salon, setSalon] = useState(null);
  const [mekan, setMekan] = useState(null);
  const [secilenKoltuklar, setSecilenKoltuklar] = useState([]);
  const [loading, setLoading] = useState(true);
  const [koltukDuzeni, setKoltukDuzeni] = useState({ rows: 0, cols: 0, vip: [] });

  useEffect(() => {
    const fetchData = async () => {
      if (isNaN(seansId)) return;

      try {
        setLoading(true);
        const { data: seansData, error: seansHata } = await supabase
          .from('seanslar')
          .select('*, filmler(*), salonlar(*, mekanlar(*))')
          .eq('id', seansId)
          .single();

        if (seansHata || !seansData) throw seansHata || new Error('Seans bulunamadı');

        setSeans(seansData);
        setFilm(seansData.filmler);
        setSalon(seansData.salonlar);
        setMekan(seansData.salonlar.mekanlar);

        if (seansData.salonlar.koltuk_duzeni) {
          const duzen = JSON.parse(seansData.salonlar.koltuk_duzeni);
          setKoltukDuzeni(duzen);
        }
      } catch (err) {
        console.error('Hata:', err);
        Alert.alert('Hata', 'Seans bilgisi alınamadı');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [seansId]);

  const koltukSec = (seatId) => {
    setSecilenKoltuklar(prev => {
      if (prev.includes(seatId)) {
        return prev.filter(id => id !== seatId);
      } else {
        return [...prev, seatId];
      }
    });
  };

  const rezervasyonYap = async () => {
    if (secilenKoltuklar.length === 0) {
      Alert.alert('Uyarı', 'Lütfen en az bir koltuk seçin');
      return;
    }

    try {
      setLoading(true);
      const { data: { user } } = await supabase.auth.getUser();

      if (!user) {
        navigation.navigate('GirisYap');
        return;
      }

      const { data: rezervasyon, error } = await supabase
        .from('rezervasyonlar')
        .insert([{
          kullanici_id: user.id,
          seans_id: seansId,
          koltuklar: JSON.stringify(secilenKoltuklar),
          adet: secilenKoltuklar.length,
          toplam_tutar: secilenKoltuklar.length * seans.fiyat,
          odeme_durumu: 'tamamlandı',
          odeme_yontemi: 'kredi_karti',
          bilet_kodu: `BILET-${Date.now()}-${Math.floor(Math.random() * 1000)}`
        }])
        .select();

      if (error) throw error;

      await supabase
        .from('odeme_gecmisi')
        .insert([{
          rezervasyon_id: rezervasyon[0].id,
          odeme_tutari: rezervasyon[0].toplam_tutar,
          durum: 'tamamlandı'
        }]);

      Alert.alert(
        'Başarılı',
        `Rezervasyonunuz tamamlandı! Bilet kodu: ${rezervasyon[0].bilet_kodu}`,
        [{ text: 'Tamam', onPress: () => navigation.navigate('Profil') }]
      );
    } catch (err) {
      console.error('Rezervasyon Hatası:', err);
      Alert.alert('Hata', 'Rezervasyon sırasında hata oluştu');
    } finally {
      setLoading(false);
    }
  };

  const renderKoltukSatiri = (rowIndex) => {
    const satirKoltuklar = [];
    for (let col = 1; col <= koltukDuzeni.cols; col++) {
      const seatId = `${String.fromCharCode(65 + rowIndex)}${col}`;
      const vipMi = koltukDuzeni.vip?.includes(seatId);
      const seciliMi = secilenKoltuklar.includes(seatId);
      const uygunMu = true; // Gerçek uygulamada uygunluk kontrolü yapılmalı

      satirKoltuklar.push(
        <TouchableOpacity
          key={seatId}
          style={[
            styles.koltuk,
            vipMi && styles.vipKoltuk,
            seciliMi && styles.seciliKoltuk,
            !uygunMu && styles.doluKoltuk,
          ]}
          onPress={() => uygunMu && koltukSec(seatId)}
          disabled={!uygunMu || loading}
        >
          <Text style={styles.koltukYazi}>{col}</Text>
        </TouchableOpacity>
      );
    }
    return (
      <View key={`satir-${rowIndex}`} style={styles.koltukSatiri}>
        <Text style={styles.satirLabel}>{String.fromCharCode(65 + rowIndex)}</Text>
        {satirKoltuklar}
      </View>
    );
  };

  if (loading) {
    return (
      <View style={styles.yukleniyorContainer}>
        <Text>Yükleniyor...</Text>
      </View>
    );
  }

  if (!seans || !film || !salon || !mekan) {
    return (
      <View style={styles.hataContainer}>
        <Text style={styles.hataMetni}>Seans bilgisi alınamadı</Text>
      </View>
    );
  }

  return (
    <ScrollView style={styles.kapsayici}>
      <LinearGradient colors={['#4A6FA5', '#3A5A80']} style={styles.baslik}>
        <Text style={styles.baslikBasligi}>Koltuk Seçimi</Text>
      </LinearGradient>

      <View style={styles.iceri}>
        <View style={styles.filmBilgisi}>
          <Text style={styles.filmAdi}>{film.ad}</Text>
          <Text style={styles.filmDetay}>
            {new Date(seans.baslangic).toLocaleDateString('tr-TR', {
              day: 'numeric',
              month: 'long',
              weekday: 'long',
            })}
            {' • '}
            {new Date(seans.baslangic).toLocaleTimeString('tr-TR', {
              hour: '2-digit',
              minute: '2-digit',
            })}
          </Text>
          <Text style={styles.filmDetay}>
            {salon.ad} • {mekan.ad}
          </Text>
        </View>

        <View style={styles.siraKisim}>
          <Text style={styles.siraMetni}>PERDE</Text>
          <View style={styles.perde} />
        </View>

        {koltukDuzeni.rows > 0 ? (
          <View style={styles.koltuklar}>
            {Array.from({ length: koltukDuzeni.rows }).map((_, index) => renderKoltukSatiri(index))}
          </View>
        ) : (
          <Text style={styles.koltukYok}>Koltuk düzeni yüklenemedi</Text>
        )}

        {/* Renk açıklamaları */}
        <View style={styles.legent}>
          <View style={styles.legentItem}>
            <View style={[styles.legentKoltuk, styles.erişilebilirKoltuk]} />
            <Text style={styles.legentYazi}>Uygun</Text>
          </View>
          <View style={styles.legentItem}>
            <View style={[styles.legentKoltuk, styles.seciliKoltuk]} />
            <Text style={styles.legentYazi}>Seçili</Text>
          </View>
          <View style={styles.legentItem}>
            <View style={[styles.legentKoltuk, styles.vipKoltuk]} />
            <Text style={styles.legentYazi}>VIP</Text>
          </View>
          <View style={styles.legentItem}>
            <View style={[styles.legentKoltuk, styles.doluKoltuk]} />
            <Text style={styles.legentYazi}>Dolu</Text>
          </View>
        </View>

        {/* Seçim Özeti */}
        <View style={styles.ozet}>
          <Text style={styles.ozetMetni}>
            {secilenKoltuklar.length} koltuk • {secilenKoltuklar.length * seans.fiyat} TL
          </Text>
        </View>

        {/* Ödeme Butonu */}
        <TouchableOpacity
          style={styles.odemeButonu}
          onPress={rezervasyonYap}
          disabled={loading || secilenKoltuklar.length === 0}
        >
          <Text style={styles.odemeButonYazi}>{loading ? 'İşleniyor...' : 'Ödemeye Geç'}</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  kapsayici: { flex: 1, backgroundColor: '#f5f5f5' },
  yukleniyorContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  hataContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 20 },
  hataMetni: { color: '#FF5252', fontSize: 16 },
  baslik: { padding: 20, paddingTop: 50, paddingBottom: 30 },
  baslikBasligi: { fontSize: 24, fontWeight: 'bold', color: '#fff' },
  iceri: { flex: 1, marginTop: -20, borderTopLeftRadius: 20, borderTopRightRadius: 20, backgroundColor: '#fff', padding: 20 },
  filmBilgisi: { marginBottom: 20, paddingBottom: 15, borderBottomWidth: 1, borderBottomColor: '#eee' },
  filmAdi: { fontSize: 20, fontWeight: 'bold', color: '#333', marginBottom: 5 },
  filmDetay: { fontSize: 16, color: '#666', marginBottom: 3 },
  siraKisim: { alignItems: 'center', marginBottom: 30 },
  siraMetni: { fontSize: 14, color: '#999', marginBottom: 5 },
  perde: { width: '80%', height: 10, backgroundColor: '#4A6FA5', borderRadius: 5 },
  koltuklar: { marginBottom: 20 },
  koltukSatiri: { flexDirection: 'row', alignItems: 'center', marginBottom: 10 },
  satirLabel: { width: 20, marginRight: 10, textAlign: 'center', fontWeight: 'bold', color: '#666' },
  koltuk: { width: 30, height: 30, borderRadius: 5, backgroundColor: '#e0e0e0', justifyContent: 'center', alignItems: 'center', marginRight: 5 },
  vipKoltuk: { backgroundColor: '#FFD700' },
  seciliKoltuk: { backgroundColor: '#4A6FA5' },
  doluKoltuk: { backgroundColor: '#FF5252' },
  koltukYazi: { fontSize: 10, fontWeight: 'bold', color: '#333' },
  koltukYok: { textAlign: 'center', color: '#999', marginVertical: 20 },
  legent: { flexDirection: 'row', justifyContent: 'space-around', marginBottom: 20 },
  legentItem: { alignItems: 'center' },
  legentKoltuk: { width: 20, height: 20, borderRadius: 3, marginBottom: 5 },
  erişilebilirKoltuk: { backgroundColor: '#e0e0e0' },
  seciliKoltuk: { backgroundColor: '#4A6FA5' },
  vipKoltuk: { backgroundColor: '#FFD700' },
  doluKoltuk: { backgroundColor: '#FF5252' },
  legentYazi: { fontSize: 12, color: '#666' },
  ozet: { borderTopWidth: 1, borderTopColor: '#eee', paddingTop: 15, marginBottom: 20, alignItems: 'center' },
  ozetMetni: { fontSize: 18, fontWeight: 'bold', color: '#4A6FA5' },
  odemeButonu: { backgroundColor: '#4A6FA5', padding: 15, borderRadius: 10, alignItems: 'center' },
  odemeButonYazi: { color: '#fff', fontSize: 18, fontWeight: 'bold' },
});

export default SeansSec;