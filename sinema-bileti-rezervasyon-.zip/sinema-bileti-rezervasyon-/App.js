
import React, { useState, useEffect } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from './lib/supabase';

// Ekranlar
import GirisYap from './screens/GirisYap';
import KayitOl from './screens/KayitOl';
import AnaSayfa from './screens/AnaSayfa';
import Filmler from './screens/Filmler';
import Profil from './screens/Profil';
import ProfilDuzenle from './screens/ProfilDuzenle';
import Ayarlar from './screens/Ayarlar';
import FilmDetay from './screens/FilmDetay';
import SeansSec from './screens/SeansSec';
import Rezervasyon from './screens/Rezervasyon';
import SinemaHaritam from './screens/harita';

const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

function AnaNavigator() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ focused, color, size }) => {
          let iconName;

          if (route.name === 'AnaSayfa') {
            iconName = focused ? 'home' : 'home-outline';
          } else if (route.name === 'Filmler') {
            iconName = focused ? 'film' : 'film-outline';
          } else if (route.name === 'Profil') {
            iconName = focused ? 'person' : 'person-outline';
          } else if (route.name === 'Ayarlar') {
            iconName = focused ? 'settings' : 'settings-outline';
          }

          return <Ionicons name={iconName} size={size} color={color} />;
        },
        tabBarActiveTintColor: '#4A6FA5',
        tabBarInactiveTintColor: '#888',
        tabBarStyle: {
          backgroundColor: '#fff',
          borderTopWidth: 0,
          elevation: 10,
          shadowOpacity: 0.1,
          shadowRadius: 10,
          height: 60,
          paddingBottom: 5,
        },
        tabBarLabelStyle: {
          fontSize: 12,
          marginBottom: 5,
        },
      })}
    >
      <Tab.Screen name="AnaSayfa" component={AnaSayfa} options={{ title: 'Ana Sayfa', headerShown: false }} />
      <Tab.Screen name="Filmler" component={Filmler} options={{ title: 'Filmler', headerShown: false }} />
      <Tab.Screen name="Profil" component={Profil} options={{ title: 'Profil', headerShown: false }} />
      <Tab.Screen name="Ayarlar" component={Ayarlar} options={{ title: 'Ayarlar', headerShown: false }} />
    </Tab.Navigator>
  );
}

export default function App() {
  const [kullanici, setKullanici] = useState(null);
  const [yukleniyor, setYukleniyor] = useState(true);

  useEffect(() => {
    const kullaniciSessionKontrol = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      setKullanici(session?.user ?? null);
      setYukleniyor(false);
    };

    kullaniciSessionKontrol();

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setKullanici(session?.user ?? null);
    });

    return () => subscription.unsubscribe();
  }, []);

  if (yukleniyor) {
    return null;
  }

  return (
    <NavigationContainer>
      <Stack.Navigator
        screenOptions={{
          headerStyle: {
            backgroundColor: '#4A6FA5',
          },
          headerTintColor: '#fff',
          headerTitleStyle: {
            fontWeight: 'bold',
          },
          headerShadowVisible: false,
        }}
      >
        {!kullanici ? (
          <>
            <Stack.Screen 
              name="GirisYap" 
              component={GirisYap} 
              options={{ title: 'Giriş Yap', headerShown: false }} 
            />
            <Stack.Screen 
              name="KayitOl" 
              component={KayitOl} 
              options={{ title: 'Kayıt Ol', headerShown: false }} 
            />
             <Stack.Screen 
              name="SinemaHaritam" 
              component={SinemaHaritam} 
              options={{ title: 'Sinema Haritam' }} 
            />
          </>
        ) : (
          <>
            <Stack.Screen 
              name="AnaNavigator" 
              component={AnaNavigator} 
              options={{ headerShown: false }} 
            />
            <Stack.Screen 
              name="FilmDetay" 
              component={FilmDetay} 
              options={{ title: 'Film Detayı' }} 
            />
            <Stack.Screen 
              name="SinemaHaritam" 
              component={SinemaHaritam} 
              options={{ title: 'Sinema Haritam' }} 
            />
            <Stack.Screen 
              name="SeansSec" 
              component={SeansSec} 
              options={{ title: 'Koltuk Seçimi' }} 
            />
            <Stack.Screen 
              name="Rezervasyon" 
              component={Rezervasyon} 
              options={{ title: 'Rezervasyon' }} 
            />
            <Stack.Screen 
              name="ProfilDuzenle" 
              component={ProfilDuzenle} 
              options={{ title: 'Profili Düzenle' }} 
            />
          </>
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
}